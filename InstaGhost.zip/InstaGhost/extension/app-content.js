// Content script for the analyzer app (localhost:5000)
// Bridges chrome extension messages to window postMessage for the React app

console.log('Instagram Follower Analyzer app content script loaded');

// Listen for messages from the background service worker
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('App content script received message:', request);
  
  if (request.type === 'INSTAGRAM_DATA' && request.source === 'ig-analyzer-extension') {
    try {
      // Forward the data to the React app via postMessage
      window.postMessage({
        type: 'INSTAGRAM_DATA',
        payload: request.payload,
        source: 'ig-analyzer-extension'
      }, window.location.origin);
      
      sendResponse({ success: true });
    } catch (error) {
      console.error('Error forwarding data to React app:', error);
      sendResponse({ success: false, error: error.message });
    }
  } else {
    sendResponse({ success: false, error: 'Invalid message type or source' });
  }
});

// Add visual indicator that extension is connected
function addExtensionIndicator() {
  if (document.getElementById('ig-analyzer-extension-indicator')) return;
  
  const indicator = document.createElement('div');
  indicator.id = 'ig-analyzer-extension-indicator';
  indicator.style.cssText = `
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: linear-gradient(45deg, #0ea5e9, #8b5cf6);
    color: white;
    padding: 8px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 500;
    z-index: 9999;
    box-shadow: 0 2px 8px rgba(0,0,0,0.2);
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    opacity: 0;
    transform: translateY(20px);
    transition: all 0.3s ease;
  `;
  indicator.textContent = '🔗 Extension Connected';
  
  document.body.appendChild(indicator);
  
  // Animate in
  setTimeout(() => {
    indicator.style.opacity = '1';
    indicator.style.transform = 'translateY(0)';
  }, 100);
  
  // Remove after 3 seconds
  setTimeout(() => {
    indicator.style.opacity = '0';
    indicator.style.transform = 'translateY(20px)';
    setTimeout(() => {
      if (indicator.parentNode) {
        indicator.parentNode.removeChild(indicator);
      }
    }, 300);
  }, 3000);
}

// Add indicator when page loads
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', addExtensionIndicator);
} else {
  addExtensionIndicator();
}