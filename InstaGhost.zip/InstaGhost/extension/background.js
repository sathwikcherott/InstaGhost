// Background service worker for Instagram Follower Analyzer extension
// Handles message routing between Instagram tab, analyzer app tab, and popup

let analyzerTabId = null;
let instagramTabId = null;

// Keep track of analyzer app tabs
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && tab.url.includes('localhost:5000')) {
    analyzerTabId = tabId;
    console.log('Analyzer tab detected:', tabId);
  }
});

// Keep track of Instagram tabs
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && tab.url.includes('instagram.com')) {
    instagramTabId = tabId;
    console.log('Instagram tab detected:', tabId);
  }
});

// Handle tab removal
chrome.tabs.onRemoved.addListener((tabId) => {
  if (tabId === analyzerTabId) {
    analyzerTabId = null;
  }
  if (tabId === instagramTabId) {
    instagramTabId = null;
  }
});

// Handle messages from popup and content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Background received message:', request);

  if (request.type === 'START_CAPTURE') {
    handleStartCapture(sendResponse);
    return true; // Keep message channel open for async response
  }
  
  if (request.type === 'INSTAGRAM_DATA_CAPTURED') {
    handleDataCaptured(request.data, sendResponse);
    return true;
  }
  
  if (request.type === 'GET_STATUS') {
    sendResponse({
      analyzerTabReady: analyzerTabId !== null,
      instagramTabReady: instagramTabId !== null
    });
  }
  
  // Forward progress/error messages from content script to popup
  if (request.type === 'CAPTURE_PROGRESS' || request.type === 'CAPTURE_ERROR') {
    forwardToPopup(request);
  }
});

async function handleStartCapture(sendResponse) {
  try {
    // Check if both tabs are available
    if (!instagramTabId) {
      sendResponse({ success: false, error: 'No Instagram tab found. Please open Instagram first.' });
      return;
    }
    
    if (!analyzerTabId) {
      sendResponse({ success: false, error: 'Analyzer app not found. Please open the app first.' });
      return;
    }

    // Send capture request to Instagram content script
    chrome.tabs.sendMessage(instagramTabId, {
      type: 'START_INSTAGRAM_CAPTURE'
    });

    sendResponse({ success: true });
  } catch (error) {
    console.error('Error starting capture:', error);
    sendResponse({ success: false, error: error.message });
  }
}

async function handleDataCaptured(data, sendResponse) {
  try {
    // Send data to analyzer app if tab is available
    if (analyzerTabId) {
      chrome.tabs.sendMessage(analyzerTabId, {
        type: 'INSTAGRAM_DATA',
        payload: data,
        source: 'ig-analyzer-extension'
      }, (response) => {
        if (chrome.runtime.lastError || !response?.success) {
          // Data delivery failed
          sendResponse({ success: false, error: 'Failed to deliver data to analyzer app' });
          forwardToPopup({ type: 'CAPTURE_ERROR', error: 'Failed to deliver data to analyzer app' });
        } else {
          // Data delivered successfully
          sendResponse({ success: true });
          forwardToPopup({ type: 'CAPTURE_COMPLETE' });
        }
      });
    } else {
      const error = 'Analyzer app not found. Please open the app first.';
      sendResponse({ success: false, error });
      forwardToPopup({ type: 'CAPTURE_ERROR', error });
    }
  } catch (error) {
    console.error('Error sending data to analyzer:', error);
    const errorMsg = error.message;
    sendResponse({ success: false, error: errorMsg });
    forwardToPopup({ type: 'CAPTURE_ERROR', error: errorMsg });
  }
}

// Find analyzer tab on startup
chrome.tabs.query({ url: 'http://localhost:5000/*' }, (tabs) => {
  if (tabs.length > 0) {
    analyzerTabId = tabs[0].id;
    console.log('Found existing analyzer tab:', analyzerTabId);
  }
});

// Find Instagram tab on startup
chrome.tabs.query({ url: 'https://www.instagram.com/*' }, (tabs) => {
  if (tabs.length > 0) {
    instagramTabId = tabs[0].id;
    console.log('Found existing Instagram tab:', instagramTabId);
  }
});

// Forward messages to popup
function forwardToPopup(message) {
  // Send to all extension pages (popup) using callback-based API
  chrome.runtime.sendMessage(message, () => {
    // Ignore lastError - popup might not be open, which is fine
    if (chrome.runtime.lastError) {
      console.log('Could not forward message to popup:', message.type);
    }
  });
}