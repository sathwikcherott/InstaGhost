// Content script for Instagram pages
// Handles Instagram data capture and communication with background service worker

console.log('Instagram Follower Analyzer content script loaded');

let captureInProgress = false;

// Listen for messages from background service worker
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Instagram content script received message:', request);
  
  if (request.type === 'START_INSTAGRAM_CAPTURE') {
    if (!captureInProgress) {
      startInstagramCapture();
    }
    sendResponse({ success: true });
  }
});

async function startInstagramCapture() {
  if (captureInProgress) return;
  
  captureInProgress = true;
  console.log('Starting Instagram data capture...');
  
  try {
    // Send progress updates to popup via background
    chrome.runtime.sendMessage({
      type: 'CAPTURE_PROGRESS',
      progress: 10,
      text: 'Analyzing page structure...'
    });

    // Simulate data capture process
    // In a real implementation, this would scrape actual Instagram data
    await delay(1000);
    
    chrome.runtime.sendMessage({
      type: 'CAPTURE_PROGRESS',
      progress: 50,
      text: 'Collecting followers...'
    });
    
    await delay(1500);
    
    chrome.runtime.sendMessage({
      type: 'CAPTURE_PROGRESS',
      progress: 80,
      text: 'Collecting following...'
    });
    
    await delay(1000);
    
    // Mock data that matches the app's expected format
    const mockData = {
      followers: [
        { username: "real_follower_1", displayName: "Real Follower One" },
        { username: "real_follower_2", displayName: "Real Follower Two" },
        { username: "mutual_user_1", displayName: "Mutual Friend" },
        { username: "real_follower_3", displayName: "Real Follower Three" },
        { username: "real_follower_4", displayName: "Real Follower Four" }
      ],
      following: [
        { username: "mutual_user_1", displayName: "Mutual Friend" },
        { username: "non_follower_1", displayName: "Non Follower One" },
        { username: "non_follower_2", displayName: "Non Follower Two", verified: true },
        { username: "non_follower_3", displayName: "Non Follower Three" }
      ]
    };
    
    // Send captured data to background service worker and wait for confirmation
    chrome.runtime.sendMessage({
      type: 'INSTAGRAM_DATA_CAPTURED',
      data: mockData
    }, (response) => {
      if (chrome.runtime.lastError || !response?.success) {
        chrome.runtime.sendMessage({
          type: 'CAPTURE_ERROR',
          error: response?.error || 'Failed to deliver data'
        });
      }
      // Note: CAPTURE_COMPLETE is now sent by background service worker only on successful delivery
    });
    
  } catch (error) {
    console.error('Capture error:', error);
    chrome.runtime.sendMessage({
      type: 'CAPTURE_ERROR',
      error: error.message
    });
  } finally {
    captureInProgress = false;
  }
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Add visual indicator that extension is active on Instagram
function addExtensionIndicator() {
  if (document.getElementById('ig-analyzer-indicator')) return;
  
  const indicator = document.createElement('div');
  indicator.id = 'ig-analyzer-indicator';
  indicator.style.cssText = `
    position: fixed;
    top: 10px;
    right: 10px;
    background: linear-gradient(45deg, #f09433 0%,#e6683c 25%,#dc2743 50%,#cc2366 75%,#bc1888 100%);
    color: white;
    padding: 8px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 500;
    z-index: 9999;
    box-shadow: 0 2px 8px rgba(0,0,0,0.2);
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    opacity: 0;
    transform: translateY(-20px);
    transition: all 0.3s ease;
  `;
  indicator.textContent = '📊 Analyzer Ready';
  
  document.body.appendChild(indicator);
  
  // Animate in
  setTimeout(() => {
    indicator.style.opacity = '1';
    indicator.style.transform = 'translateY(0)';
  }, 100);
  
  // Remove after 3 seconds
  setTimeout(() => {
    indicator.style.opacity = '0';
    indicator.style.transform = 'translateY(-20px)';
    setTimeout(() => {
      if (indicator.parentNode) {
        indicator.parentNode.removeChild(indicator);
      }
    }, 300);
  }, 3000);
}

// Add indicator when page loads
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', addExtensionIndicator);
} else {
  addExtensionIndicator();
}