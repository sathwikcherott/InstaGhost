document.addEventListener('DOMContentLoaded', function() {
  const startBtn = document.getElementById('startBtn');
  const openAppBtn = document.getElementById('openAppBtn');
  const statusDiv = document.getElementById('status');
  const progressDiv = document.getElementById('progress');
  const progressFill = document.getElementById('progressFill');
  const progressText = document.getElementById('progressText');
  const helpLink = document.getElementById('helpLink');

  let isCapturing = false;

  let statusReady = false;
  
  // Check status on popup open
  function checkStatus() {
    chrome.runtime.sendMessage({ type: 'GET_STATUS' }, (response) => {
      if (response && response.analyzerTabReady && response.instagramTabReady) {
        showStatus('Ready to capture data', 'ready');
        statusReady = true;
        startBtn.disabled = false;
      } else if (!response.analyzerTabReady) {
        showStatus('Please open the Analyzer app first', 'error');
        statusReady = false;
        startBtn.disabled = true;
      } else if (!response.instagramTabReady) {
        showStatus('Please open Instagram first', 'error');
        statusReady = false;
        startBtn.disabled = true;
      }
    });
  }
  
  checkStatus();

  startBtn.addEventListener('click', async function() {
    if (isCapturing) return;
    
    // Re-check status before starting
    if (!statusReady) {
      checkStatus();
      return;
    }
    
    startCapture();
  });

  openAppBtn.addEventListener('click', function() {
    chrome.tabs.create({ url: 'http://localhost:5000' });
  });

  helpLink.addEventListener('click', function(e) {
    e.preventDefault();
    chrome.tabs.create({ url: 'http://localhost:5000' });
  });

  async function startCapture() {
    isCapturing = true;
    startBtn.disabled = true;
    showStatus('Starting capture...', 'waiting');
    progressDiv.style.display = 'block';
    
    try {
      // Send capture request to background service worker
      chrome.runtime.sendMessage({ type: 'START_CAPTURE' }, (response) => {
        if (!response.success) {
          showStatus(response.error, 'error');
          isCapturing = false;
          startBtn.disabled = false;
          progressDiv.style.display = 'none';
        }
      });
      
    } catch (error) {
      console.error('Capture error:', error);
      showStatus('Capture failed', 'error');
      isCapturing = false;
      startBtn.disabled = false;
      progressDiv.style.display = 'none';
    }
  }

  function showStatus(message, type) {
    statusDiv.textContent = message;
    statusDiv.className = `status ${type}`;
  }

  function updateProgress(percent, text) {
    progressFill.style.width = percent + '%';
    progressText.textContent = text;
  }

  // Listen for messages from content scripts via background
  chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    console.log('Popup received message:', request);
    
    if (request.type === 'CAPTURE_PROGRESS') {
      updateProgress(request.progress, request.text);
    } else if (request.type === 'CAPTURE_COMPLETE') {
      showStatus('Capture complete!', 'ready');
      updateProgress(100, 'Data sent to analyzer app');
      
      // Show success state
      setTimeout(() => {
        progressDiv.style.display = 'none';
        openAppBtn.style.display = 'block';
        startBtn.style.display = 'none';
        showStatus('Success! View results in analyzer app', 'ready');
        isCapturing = false;
      }, 1000);
      
    } else if (request.type === 'CAPTURE_ERROR') {
      showStatus('Capture failed: ' + request.error, 'error');
      progressDiv.style.display = 'none';
      isCapturing = false;
      startBtn.disabled = false;
    }
  });
});