# Instagram Follower Analyzer Extension

This browser extension works with the Instagram Follower Analyzer web app to automatically capture your Instagram follower and following data.

## Installation

1. Open Chrome and go to `chrome://extensions/`
2. Enable "Developer mode" in the top right
3. Click "Load unpacked" and select this extension folder
4. The extension icon should appear in your browser toolbar

## Usage

1. Open the Instagram Follower Analyzer web app (http://localhost:5000)
2. Choose "Auto-Capture" method
3. Make sure you're logged into Instagram in another tab
4. Click the extension icon and follow the instructions
5. Your data will be automatically sent to the analyzer app

## Privacy & Security

- Your Instagram login credentials never leave your browser
- The extension only reads public follower information while you're logged in
- All data processing happens locally in your browser
- No data is sent to external servers

## How It Works

1. **Content Script**: Runs on Instagram pages to detect when you're logged in
2. **Popup Interface**: Provides controls to start the data capture process
3. **Data Communication**: Safely sends captured data to the analyzer app via postMessage
4. **Local Processing**: All analysis happens in your browser - no server uploads required

## Troubleshooting

- Make sure you're logged into Instagram
- Ensure the analyzer app is open in another tab
- Check that the extension is enabled in Chrome
- Try refreshing the Instagram page if capture fails

## Technical Details

- Uses Manifest V3 for modern Chrome compatibility
- Implements secure postMessage communication
- Requires minimal permissions (only Instagram access)
- No background processes - only runs when needed