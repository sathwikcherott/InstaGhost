import { useState } from "react";
import Header from "@/components/Header";
import MethodSelector from "@/components/MethodSelector";
import InstructionsCard from "@/components/InstructionsCard";
import FileUpload from "@/components/FileUpload";
import ExtensionSetup from "@/components/ExtensionSetup";
import ProgressIndicator from "@/components/ProgressIndicator";
import StatisticsCard from "@/components/StatisticsCard";
import AnalysisResults from "@/components/AnalysisResults";
import { Button } from "@/components/ui/button";
import { Users, UserCheck, UserX, RotateCcw } from "lucide-react";
import { 
  processInstagramData, 
  parseInstagramFiles, 
  validateExtensionData, 
  exportToCSV, 
  downloadCSV 
} from "@/utils/dataProcessor";
import type { AnalysisResult } from "@shared/schema";

interface AnalysisState {
  selectedMethod: 'upload' | 'extension' | null;
  followersFile: File | null;
  followingFile: File | null;
  extensionData: any | null;
  isAnalyzing: boolean;
  analysisComplete: boolean;
  results: AnalysisResult | null;
}

export default function Home() {
  const [state, setState] = useState<AnalysisState>({
    selectedMethod: null,
    followersFile: null,
    followingFile: null,
    extensionData: null,
    isAnalyzing: false,
    analysisComplete: false,
    results: null
  });

  const handleMethodSelect = (method: 'upload' | 'extension') => {
    console.log('Method selected:', method);
    setState(prev => ({ ...prev, selectedMethod: method }));
  };

  const handleGoBack = () => {
    console.log('Going back to method selection');
    setState(prev => ({ 
      ...prev, 
      selectedMethod: null,
      followersFile: null,
      followingFile: null,
      extensionData: null
    }));
  };

  const handleFollowersFileSelect = (file: File) => {
    console.log('Followers file selected:', file.name);
    setState(prev => ({ ...prev, followersFile: file }));
  };

  const handleFollowingFileSelect = (file: File) => {
    console.log('Following file selected:', file.name);
    setState(prev => ({ ...prev, followingFile: file }));
  };

  const handleExtensionData = async (data: any) => {
    console.log('Extension data received:', data);
    setState(prev => ({ 
      ...prev, 
      extensionData: data,
      isAnalyzing: true
    }));
    
    try {
      // Validate and process extension data
      const validatedData = validateExtensionData(data);
      const results = processInstagramData(validatedData);
      
      // Simulate processing time for better UX
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      setState(prev => ({
        ...prev,
        isAnalyzing: false,
        analysisComplete: true,
        results
      }));
    } catch (error) {
      console.error('Error processing extension data:', error);
      setState(prev => ({
        ...prev,
        isAnalyzing: false,
        analysisComplete: false
      }));
      // todo: add proper error handling with toast notifications
    }
  };

  const handleAnalyze = async () => {
    if (!state.followersFile || !state.followingFile) return;
    
    console.log('Starting analysis...');
    setState(prev => ({ ...prev, isAnalyzing: true }));
    
    try {
      // Parse uploaded files
      const instagramData = await parseInstagramFiles(state.followersFile, state.followingFile);
      const results = processInstagramData(instagramData);
      
      // Simulate processing time for better UX
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      setState(prev => ({
        ...prev,
        isAnalyzing: false,
        analysisComplete: true,
        results
      }));
    } catch (error) {
      console.error('Error analyzing files:', error);
      setState(prev => ({
        ...prev,
        isAnalyzing: false,
        analysisComplete: false
      }));
      // todo: add proper error handling with toast notifications
    }
  };

  const handleReset = () => {
    console.log('Resetting analysis...');
    setState({
      selectedMethod: null,
      followersFile: null,
      followingFile: null,
      extensionData: null,
      isAnalyzing: false,
      analysisComplete: false,
      results: null
    });
  };

  const handleExport = () => {
    if (!state.results) return;
    
    console.log('Exporting results to CSV...');
    const csvContent = exportToCSV(state.results);
    downloadCSV(csvContent, 'instagram-non-followers.csv');
  };

  const analysisSteps = [
    { label: 'Reading followers file', status: state.followersFile ? 'completed' as const : 'pending' as const },
    { label: 'Reading following file', status: state.followingFile ? 'completed' as const : 'pending' as const },
    { label: 'Analyzing data differences', status: state.isAnalyzing ? 'processing' as const : 'pending' as const },
    { label: 'Generating results', status: state.analysisComplete ? 'completed' as const : 'pending' as const }
  ];

  const canAnalyze = (state.followersFile && state.followingFile && !state.isAnalyzing) || 
                    (state.extensionData && !state.isAnalyzing);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-6 py-8">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Method Selection */}
          {!state.selectedMethod && !state.analysisComplete && (
            <MethodSelector onSelectMethod={handleMethodSelect} />
          )}

          {/* File Upload Flow */}
          {state.selectedMethod === 'upload' && !state.analysisComplete && (
            <>
              <InstructionsCard />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FileUpload
                  title="Followers List"
                  description="Upload your followers_1.json file"
                  accept=".json"
                  onFileSelect={handleFollowersFileSelect}
                  isUploaded={!!state.followersFile}
                  uploadedFileName={state.followersFile?.name}
                />
                <FileUpload
                  title="Following List"
                  description="Upload your following.json file"
                  accept=".json"
                  onFileSelect={handleFollowingFileSelect}
                  isUploaded={!!state.followingFile}
                  uploadedFileName={state.followingFile?.name}
                />
              </div>

              <div className="flex justify-center">
                <div className="flex gap-3">
                  <Button 
                    variant="outline"
                    onClick={handleGoBack}
                    size="lg"
                    data-testid="button-back-to-methods"
                  >
                    <RotateCcw className="w-4 h-4 mr-2" />
                    Change Method
                  </Button>
                  <Button 
                    onClick={handleAnalyze}
                    disabled={!canAnalyze}
                    size="lg"
                    data-testid="button-analyze"
                  >
                    {state.isAnalyzing ? "Analyzing..." : "Analyze Followers"}
                  </Button>
                </div>
              </div>
            </>
          )}

          {/* Extension Setup Flow */}
          {state.selectedMethod === 'extension' && !state.analysisComplete && (
            <ExtensionSetup 
              onDataReceived={handleExtensionData}
              onGoBack={handleGoBack}
            />
          )}

          {/* Progress Indicator */}
          {(state.isAnalyzing || state.analysisComplete) && (
            <>
              <ProgressIndicator 
                steps={analysisSteps}
                currentStep={state.analysisComplete ? 3 : state.isAnalyzing ? 2 : 1}
                progress={state.analysisComplete ? 100 : state.isAnalyzing ? 65 : 50}
              />
              
              {state.analysisComplete && (
                <div className="flex justify-center">
                  <Button 
                    variant="outline"
                    onClick={handleReset}
                    size="lg"
                    data-testid="button-start-over"
                  >
                    <RotateCcw className="w-4 h-4 mr-2" />
                    Start Over
                  </Button>
                </div>
              )}
            </>
          )}

          {/* Results Section */}
          {state.results && (
            <div className="space-y-6">
              {/* Statistics */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <StatisticsCard
                  title="Total Followers"
                  value={state.results.totalFollowers}
                  icon={Users}
                  description="People following you"
                />
                <StatisticsCard
                  title="Total Following"
                  value={state.results.totalFollowing}
                  icon={UserCheck}
                  description="People you follow"
                  colorClass="text-blue-600"
                />
                <StatisticsCard
                  title="Don't Follow Back"
                  value={state.results.nonFollowers.length}
                  icon={UserX}
                  description="Not following you back"
                  colorClass="text-red-600"
                />
              </div>

              {/* Detailed Results */}
              <AnalysisResults 
                nonFollowers={state.results.nonFollowers}
                onExport={handleExport}
              />
            </div>
          )}
        </div>
      </main>
    </div>
  );
}