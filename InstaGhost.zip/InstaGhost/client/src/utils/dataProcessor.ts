import { InstagramUser, InstagramData, AnalysisResult } from "@shared/schema";

/**
 * Process Instagram data from files or extension
 */
export function processInstagramData(data: InstagramData): AnalysisResult {
  const { followers, following } = data;
  
  // Find users who are followed but don't follow back
  const nonFollowers = following.filter(followedUser => 
    !followers.some(follower => follower.username === followedUser.username)
  );
  
  // Find mutual follows (follow each other)
  const mutualFollows = following.filter(followedUser =>
    followers.some(follower => follower.username === followedUser.username)
  );
  
  return {
    totalFollowers: followers.length,
    totalFollowing: following.length,
    nonFollowers,
    mutualFollows
  };
}

/**
 * Parse Instagram data export files (JSON format)
 */
export async function parseInstagramFiles(
  followersFile: File, 
  followingFile: File
): Promise<InstagramData> {
  try {
    const [followersText, followingText] = await Promise.all([
      followersFile.text(),
      followingFile.text()
    ]);
    
    const followersData = JSON.parse(followersText);
    const followingData = JSON.parse(followingText);
    
    // Instagram export format varies, handle common structures
    const followers = extractUsers(followersData);
    const following = extractUsers(followingData);
    
    return { followers, following };
  } catch (error) {
    throw new Error(`Failed to parse Instagram files: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

/**
 * Extract user data from Instagram export JSON structure
 */
function extractUsers(jsonData: any): InstagramUser[] {
  // Handle different Instagram export formats
  let userArray: any[] = [];
  
  if (Array.isArray(jsonData)) {
    userArray = jsonData;
  } else if (jsonData.relationships_following) {
    userArray = jsonData.relationships_following;
  } else if (jsonData.relationships_followers) {
    userArray = jsonData.relationships_followers;
  } else if (jsonData.data) {
    userArray = jsonData.data;
  } else {
    // Try to find any array in the object
    const arrays = Object.values(jsonData).filter(Array.isArray);
    if (arrays.length > 0) {
      userArray = arrays[0] as any[];
    }
  }
  
  return userArray.map((item: any) => {
    // Handle different user object structures
    const userObj = item.string_list_data?.[0] || item;
    
    return {
      username: userObj.value || userObj.username || userObj.href?.split('/').pop() || 'unknown',
      displayName: userObj.title || userObj.displayName || userObj.full_name,
      verified: userObj.verified || false,
      profileUrl: userObj.href || `https://instagram.com/${userObj.value || userObj.username}`
    };
  }).filter(user => user.username !== 'unknown');
}

/**
 * Validate extension data format
 */
export function validateExtensionData(data: any): InstagramData {
  try {
    // Ensure the data has the expected structure
    if (!data || typeof data !== 'object') {
      throw new Error('Invalid data format');
    }
    
    const followers = Array.isArray(data.followers) ? data.followers : [];
    const following = Array.isArray(data.following) ? data.following : [];
    
    return {
      followers: followers.map(normalizeUser),
      following: following.map(normalizeUser)
    };
  } catch (error) {
    throw new Error(`Invalid extension data: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

/**
 * Normalize user object to consistent format
 */
function normalizeUser(user: any): InstagramUser {
  return {
    username: user.username || user.value || 'unknown',
    displayName: user.displayName || user.title || user.full_name,
    verified: Boolean(user.verified),
    profileUrl: user.profileUrl || user.href || `https://instagram.com/${user.username || user.value}`
  };
}

/**
 * Export analysis results to CSV format
 */
export function exportToCSV(result: AnalysisResult): string {
  const csvRows = [
    ['Username', 'Display Name', 'Verified', 'Profile URL'], // Header
    ...result.nonFollowers.map(user => [
      user.username,
      user.displayName || '',
      user.verified ? 'Yes' : 'No',
      user.profileUrl || `https://instagram.com/${user.username}`
    ])
  ];
  
  return csvRows.map(row => 
    row.map(field => `"${field.toString().replace(/"/g, '""')}"`).join(',')
  ).join('\n');
}

/**
 * Download CSV file
 */
export function downloadCSV(csvContent: string, filename: string = 'non-followers.csv') {
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  
  if (link.download !== undefined) {
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}