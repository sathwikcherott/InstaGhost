import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Download, 
  Chrome, 
  CheckCircle, 
  AlertCircle, 
  Loader2,
  ArrowLeft,
  ExternalLink 
} from "lucide-react";

interface ExtensionSetupProps {
  onDataReceived: (data: any) => void;
  onGoBack: () => void;
}

interface ConnectionStatus {
  extensionInstalled: boolean;
  connected: boolean;
  listening: boolean;
}

export default function ExtensionSetup({ onDataReceived, onGoBack }: ExtensionSetupProps) {
  const [status, setStatus] = useState<ConnectionStatus>({
    extensionInstalled: false,
    connected: false,
    listening: false
  });
  const [isWaiting, setIsWaiting] = useState(false);

  useEffect(() => {
    // Check if extension is installed by looking for a custom event
    const checkExtension = () => {
      // In a real implementation, the extension would set a flag
      // For now, we'll simulate this check
      setStatus(prev => ({ ...prev, extensionInstalled: false }));
    };

    checkExtension();

    // Listen for messages from the extension
    const handleMessage = (event: MessageEvent) => {
      // Validate message origin and source for security
      if (event.origin !== window.location.origin) return;
      if (event.data.source !== 'ig-analyzer-extension') return;
      
      if (event.data.type === 'INSTAGRAM_DATA' && event.data.payload) {
        console.log('Received Instagram data from extension:', event.data.payload);
        setStatus(prev => ({ ...prev, connected: true }));
        setIsWaiting(false);
        onDataReceived(event.data.payload);
      }
    };

    window.addEventListener('message', handleMessage);
    setStatus(prev => ({ ...prev, listening: true }));

    return () => {
      window.removeEventListener('message', handleMessage);
      setStatus(prev => ({ ...prev, listening: false }));
    };
  }, [onDataReceived]);

  const handleStartCapture = () => {
    console.log('Please use the extension popup to start capture');
    // Direct users to use the extension popup instead of in-app button
    alert('Please use the browser extension popup to start data capture. Click the extension icon in your browser toolbar.');
  };

  const handleDownloadExtension = () => {
    console.log('Download extension clicked');
    // In a real implementation, this would point to Chrome Web Store
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={onGoBack}
          data-testid="button-go-back"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Methods
        </Button>
        <div>
          <h2 className="text-2xl font-bold">Auto-Capture Setup</h2>
          <p className="text-muted-foreground">
            Install our extension to instantly capture your Instagram data
          </p>
        </div>
      </div>

      {/* Extension Download Card */}
      <Card className={`border-2 ${status.extensionInstalled ? 'border-green-300 bg-green-50 dark:bg-green-950/20' : 'border-blue-300 bg-blue-50 dark:bg-blue-950/20'}`}>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Chrome className="w-5 h-5" />
            Instagram Follower Analyzer Extension
            {status.extensionInstalled ? (
              <Badge variant="outline" className="text-green-600 border-green-600">
                <CheckCircle className="w-3 h-3 mr-1" />
                Installed
              </Badge>
            ) : (
              <Badge variant="outline" className="text-blue-600 border-blue-600">
                Required
              </Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {!status.extensionInstalled ? (
            <>
              <p className="text-sm text-muted-foreground">
                Our browser extension safely captures your follower data while you're logged into Instagram. 
                Your login credentials never leave your browser.
              </p>
              <div className="flex gap-3">
                <Button onClick={handleDownloadExtension} data-testid="button-download-extension">
                  <Download className="w-4 h-4 mr-2" />
                  Install Extension
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => setStatus(prev => ({ ...prev, extensionInstalled: true }))}
                  data-testid="button-simulate-install"
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  I've Installed It
                </Button>
              </div>
            </>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-green-600">
                <CheckCircle className="w-4 h-4" />
                <span className="text-sm">Extension is ready to use</span>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Connection Status */}
      {status.extensionInstalled && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              Connection Status
              {status.listening ? (
                <Badge variant="outline" className="text-green-600 border-green-600">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  Ready
                </Badge>
              ) : (
                <Badge variant="outline" className="text-yellow-600 border-yellow-600">
                  <AlertCircle className="w-3 h-3 mr-1" />
                  Not Connected
                </Badge>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className={`flex items-center gap-2 ${status.listening ? 'text-green-600' : 'text-muted-foreground'}`}>
                <CheckCircle className="w-4 h-4" />
                <span className="text-sm">Listening for extension data</span>
              </div>
              <div className={`flex items-center gap-2 ${status.connected ? 'text-green-600' : 'text-muted-foreground'}`}>
                <CheckCircle className="w-4 h-4" />
                <span className="text-sm">Connection established</span>
              </div>
            </div>

            {!isWaiting ? (
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Make sure you're logged into Instagram in another tab, then click below to start capturing your data.
                </p>
                <Button 
                  onClick={handleStartCapture}
                  disabled={!status.listening}
                  data-testid="button-start-capture"
                >
                  Start Data Capture
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-primary">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span className="text-sm">Capturing your Instagram data...</span>
                </div>
                <p className="text-xs text-muted-foreground">
                  This may take a few moments depending on how many followers you have.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Instructions Card */}
      <Card className="border-yellow-200 bg-yellow-50/50 dark:border-yellow-800 dark:bg-yellow-950/20">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-yellow-600" />
            How It Works
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <ol className="list-decimal list-inside space-y-2 text-sm">
            <li>Install the browser extension (it's safe and open-source)</li>
            <li>Make sure you're logged into Instagram in another browser tab</li>
            <li>Click "Start Data Capture" - the extension will visit your follower pages</li>
            <li>Your data is processed locally and sent directly to this page</li>
            <li>View your results instantly - no downloads required!</li>
          </ol>
          <div className="p-3 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-800">
            <p className="text-sm text-blue-800 dark:text-blue-200">
              <strong>Privacy:</strong> Your Instagram login never leaves your browser. 
              The extension only reads public follower information while you're logged in.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}