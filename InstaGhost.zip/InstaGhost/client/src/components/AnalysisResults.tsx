import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, Download } from "lucide-react";
import { useState } from "react";

interface NonFollower {
  username: string;
  displayName?: string;
  profileUrl?: string;
  verified?: boolean;
}

interface AnalysisResultsProps {
  nonFollowers: NonFollower[];
  onExport?: () => void;
}

export default function AnalysisResults({ nonFollowers, onExport }: AnalysisResultsProps) {
  const [sortBy, setSortBy] = useState<'username' | 'verified'>('username');

  const sortedNonFollowers = [...nonFollowers].sort((a, b) => {
    if (sortBy === 'verified') {
      if (a.verified && !b.verified) return -1;
      if (!a.verified && b.verified) return 1;
    }
    return a.username.localeCompare(b.username);
  });

  const handleViewProfile = (username: string) => {
    window.open(`https://instagram.com/${username}`, '_blank');
  };

  const handleExport = () => {
    console.log('Export triggered');
    onExport?.();
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              People Who Don't Follow You Back
              <Badge variant="secondary" data-testid="count-non-followers">
                {nonFollowers.length}
              </Badge>
            </CardTitle>
            <p className="text-sm text-muted-foreground mt-1">
              These users follow you, but you don't follow them back
            </p>
          </div>
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setSortBy(sortBy === 'username' ? 'verified' : 'username')}
              data-testid="button-sort"
            >
              Sort by {sortBy === 'username' ? 'Verified' : 'Username'}
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              onClick={handleExport}
              data-testid="button-export"
            >
              <Download className="w-4 h-4 mr-2" />
              Export CSV
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-2 max-h-96 overflow-y-auto">
          {sortedNonFollowers.map((user, index) => (
            <div
              key={user.username}
              className="flex items-center justify-between p-3 rounded-lg border hover-elevate"
              data-testid={`user-${user.username}`}
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-pink-500 to-purple-600 flex items-center justify-center text-white font-medium">
                  {user.username.charAt(0).toUpperCase()}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-medium">@{user.username}</span>
                    {user.verified && (
                      <Badge variant="secondary" className="text-xs">
                        Verified
                      </Badge>
                    )}
                  </div>
                  {user.displayName && (
                    <p className="text-sm text-muted-foreground">{user.displayName}</p>
                  )}
                </div>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleViewProfile(user.username)}
                data-testid={`button-view-${user.username}`}
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                View Profile
              </Button>
            </div>
          ))}
        </div>
        {nonFollowers.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            <p>Great news! Everyone you follow also follows you back.</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}