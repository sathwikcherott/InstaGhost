import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Upload, Zap, FileText, Chrome } from "lucide-react";

interface MethodSelectorProps {
  onSelectMethod: (method: 'upload' | 'extension') => void;
}

export default function MethodSelector({ onSelectMethod }: MethodSelectorProps) {
  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-2xl font-bold">Choose Your Method</h2>
        <p className="text-muted-foreground">
          Select how you'd like to analyze your Instagram followers
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* File Upload Method */}
        <Card className="hover-elevate cursor-pointer" onClick={() => onSelectMethod('upload')}>
          <CardHeader className="text-center">
            <div className="w-16 h-16 mx-auto bg-blue-100 dark:bg-blue-900/20 rounded-lg flex items-center justify-center mb-4">
              <Upload className="w-8 h-8 text-blue-600" />
            </div>
            <CardTitle className="flex items-center justify-center gap-2">
              Upload Data Files
              <Badge variant="secondary">Most Reliable</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p className="text-muted-foreground">
              Download your Instagram data and upload the follower/following files
            </p>
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2 text-green-600">
                <FileText className="w-4 h-4" />
                <span>Works 100% of the time</span>
              </div>
              <div className="flex items-center gap-2 text-green-600">
                <FileText className="w-4 h-4" />
                <span>Complete data access</span>
              </div>
              <div className="flex items-center gap-2 text-yellow-600">
                <FileText className="w-4 h-4" />
                <span>Requires 1-2 day wait for Instagram data</span>
              </div>
            </div>
            <Button 
              className="w-full" 
              variant="outline"
              data-testid="select-upload-method"
            >
              Choose Upload Method
            </Button>
          </CardContent>
        </Card>

        {/* Browser Extension Method */}
        <Card className="hover-elevate cursor-pointer" onClick={() => onSelectMethod('extension')}>
          <CardHeader className="text-center">
            <div className="w-16 h-16 mx-auto bg-primary/10 rounded-lg flex items-center justify-center mb-4">
              <Zap className="w-8 h-8 text-primary" />
            </div>
            <CardTitle className="flex items-center justify-center gap-2">
              Auto-Capture
              <Badge variant="outline">Instant</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p className="text-muted-foreground">
              Use our browser extension to instantly capture your data while logged into Instagram
            </p>
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2 text-green-600">
                <Chrome className="w-4 h-4" />
                <span>Instant results</span>
              </div>
              <div className="flex items-center gap-2 text-green-600">
                <Chrome className="w-4 h-4" />
                <span>No file downloads needed</span>
              </div>
              <div className="flex items-center gap-2 text-yellow-600">
                <Chrome className="w-4 h-4" />
                <span>Requires browser extension</span>
              </div>
            </div>
            <Button 
              className="w-full"
              data-testid="select-extension-method"
            >
              Choose Auto-Capture
            </Button>
          </CardContent>
        </Card>
      </div>

      <div className="text-center">
        <p className="text-xs text-muted-foreground">
          Both methods keep your data private and secure. Choose the one that works best for you.
        </p>
      </div>
    </div>
  );
}