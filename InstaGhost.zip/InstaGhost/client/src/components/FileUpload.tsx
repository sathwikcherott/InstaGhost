import { Upload, FileText, CheckCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useState, useRef } from "react";

interface FileUploadProps {
  title: string;
  description: string;
  accept: string;
  onFileSelect: (file: File) => void;
  isUploaded?: boolean;
  uploadedFileName?: string;
}

export default function FileUpload({ 
  title, 
  description, 
  accept, 
  onFileSelect, 
  isUploaded = false,
  uploadedFileName = ""
}: FileUploadProps) {
  const [isDragOver, setIsDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      onFileSelect(files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      onFileSelect(files[0]);
    }
  };

  const handleClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <Card className="hover-elevate">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          {isUploaded ? (
            <CheckCircle className="w-5 h-5 text-green-600" />
          ) : (
            <FileText className="w-5 h-5" />
          )}
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div
          className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors cursor-pointer ${
            isDragOver 
              ? "border-primary bg-primary/5" 
              : isUploaded
              ? "border-green-300 bg-green-50 dark:bg-green-950/20"
              : "border-muted-foreground/25 hover:border-primary/50"
          }`}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={handleClick}
          data-testid={`upload-${title.toLowerCase().replace(/\s+/g, '-')}`}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept={accept}
            onChange={handleFileChange}
            className="hidden"
            data-testid={`input-${title.toLowerCase().replace(/\s+/g, '-')}`}
          />
          
          {isUploaded ? (
            <div className="space-y-2">
              <CheckCircle className="w-8 h-8 text-green-600 mx-auto" />
              <p className="font-medium text-green-700 dark:text-green-400">
                File uploaded successfully
              </p>
              <p className="text-sm text-muted-foreground">{uploadedFileName}</p>
            </div>
          ) : (
            <div className="space-y-3">
              <Upload className="w-8 h-8 text-muted-foreground mx-auto" />
              <div>
                <p className="font-medium">
                  {isDragOver ? "Drop your file here" : "Click to upload or drag and drop"}
                </p>
                <p className="text-sm text-muted-foreground mt-1">{description}</p>
              </div>
              <Button variant="outline" size="sm" data-testid={`button-select-${title.toLowerCase().replace(/\s+/g, '-')}`}>
                Select File
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}