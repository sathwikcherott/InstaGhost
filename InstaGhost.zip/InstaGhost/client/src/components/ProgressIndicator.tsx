import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Loader2, CheckCircle } from "lucide-react";

interface ProgressIndicatorProps {
  steps: {
    label: string;
    status: 'pending' | 'processing' | 'completed';
  }[];
  currentStep?: number;
  progress?: number;
}

export default function ProgressIndicator({ steps, currentStep = 0, progress = 0 }: ProgressIndicatorProps) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-medium">Processing Your Data</h3>
            <span className="text-sm text-muted-foreground">
              Step {currentStep + 1} of {steps.length}
            </span>
          </div>
          
          <Progress value={progress} className="w-full" data-testid="progress-bar" />
          
          <div className="space-y-3">
            {steps.map((step, index) => (
              <div key={index} className="flex items-center gap-3">
                <div className="flex-shrink-0">
                  {step.status === 'completed' ? (
                    <CheckCircle className="w-5 h-5 text-green-600" />
                  ) : step.status === 'processing' ? (
                    <Loader2 className="w-5 h-5 text-primary animate-spin" />
                  ) : (
                    <div className="w-5 h-5 rounded-full border-2 border-muted-foreground/30" />
                  )}
                </div>
                <span 
                  className={`text-sm ${
                    step.status === 'completed' 
                      ? 'text-green-600 font-medium' 
                      : step.status === 'processing'
                      ? 'text-primary font-medium'
                      : 'text-muted-foreground'
                  }`}
                  data-testid={`step-${index}`}
                >
                  {step.label}
                </span>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}