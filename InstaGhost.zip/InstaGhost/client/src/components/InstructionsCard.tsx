import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Info, ChevronDown, ChevronUp, ExternalLink } from "lucide-react";
import { useState } from "react";

export default function InstructionsCard() {
  const [isExpanded, setIsExpanded] = useState(false);

  const handleLearnMore = () => {
    console.log('Learn more about data export clicked');
    // todo: remove mock functionality - should open help documentation
  };

  return (
    <Card className="border-blue-200 bg-blue-50/50 dark:border-blue-800 dark:bg-blue-950/20">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <Info className="w-5 h-5 text-blue-600" />
            How to Export Your Instagram Data
          </CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsExpanded(!isExpanded)}
            data-testid="button-toggle-instructions"
          >
            {isExpanded ? (
              <ChevronUp className="w-4 h-4" />
            ) : (
              <ChevronDown className="w-4 h-4" />
            )}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="flex flex-wrap gap-2">
            <Badge variant="outline">Privacy-focused</Badge>
            <Badge variant="outline">No login required</Badge>
            <Badge variant="outline">Data stays local</Badge>
          </div>
          
          {isExpanded && (
            <div className="space-y-4 mt-4">
              <div className="space-y-3">
                <h4 className="font-medium">Quick Steps:</h4>
                <ol className="list-decimal list-inside space-y-2 text-sm">
                  <li>Go to Instagram Settings {">"} Privacy and Security {">"} Data Download</li>
                  <li>Request a download of your data (choose JSON format)</li>
                  <li>Wait for Instagram to email you the download link (usually 1-2 days)</li>
                  <li>Download and extract the ZIP file</li>
                  <li>Upload the "followers_1.json" and "following.json" files here</li>
                </ol>
              </div>
              
              <div className="p-3 bg-yellow-50 dark:bg-yellow-950/20 rounded-lg border border-yellow-200 dark:border-yellow-800">
                <p className="text-sm text-yellow-800 dark:text-yellow-200">
                  <strong>Note:</strong> Your data never leaves your device. All analysis happens locally in your browser.
                </p>
              </div>
              
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleLearnMore}
                data-testid="button-learn-more"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                Detailed Guide
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}