import FileUpload from '../FileUpload';

export default function FileUploadExample() {
  const handleFileSelect = (file: File) => {
    console.log('File selected:', file.name);
  };

  return (
    <div className="space-y-6 p-6">
      <FileUpload
        title="Followers List"
        description="Upload your Instagram followers JSON file"
        accept=".json,.csv"
        onFileSelect={handleFileSelect}
      />
      <FileUpload
        title="Following List" 
        description="Upload your Instagram following JSON file"
        accept=".json,.csv"
        onFileSelect={handleFileSelect}
        isUploaded={true}
        uploadedFileName="following_list.json"
      />
    </div>
  );
}