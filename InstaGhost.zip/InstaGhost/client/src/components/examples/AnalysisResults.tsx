import AnalysisResults from '../AnalysisResults';

export default function AnalysisResultsExample() {
  // todo: remove mock functionality
  const mockNonFollowers = [
    {
      username: "tech_guru_2024",
      displayName: "Tech Guru",
      verified: true
    },
    {
      username: "photography_lover",
      displayName: "Sarah Photography"
    },
    {
      username: "fitness_motivation",
      displayName: "Fitness Motivation",
      verified: false
    },
    {
      username: "travel_adventures",
      displayName: "Travel Adventures"
    },
    {
      username: "food_blogger_nyc",
      displayName: "NYC Food Blogger",
      verified: true
    }
  ];

  const handleExport = () => {
    console.log('Export CSV triggered');
  };

  return (
    <div className="p-6">
      <AnalysisResults 
        nonFollowers={mockNonFollowers} 
        onExport={handleExport}
      />
    </div>
  );
}