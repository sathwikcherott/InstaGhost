import MethodSelector from '../MethodSelector';

export default function MethodSelectorExample() {
  const handleSelectMethod = (method: 'upload' | 'extension') => {
    console.log('Selected method:', method);
  };

  return (
    <div className="p-6">
      <MethodSelector onSelectMethod={handleSelectMethod} />
    </div>
  );
}