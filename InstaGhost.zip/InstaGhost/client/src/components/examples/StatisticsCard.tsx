import StatisticsCard from '../StatisticsCard';
import { Users, UserCheck, UserX } from 'lucide-react';

export default function StatisticsCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-6">
      <StatisticsCard
        title="Total Followers"
        value={1248}
        icon={Users}
        description="People following you"
      />
      <StatisticsCard
        title="Total Following"
        value={956}
        icon={UserCheck}
        description="People you follow"
        colorClass="text-blue-600"
      />
      <StatisticsCard
        title="Don't Follow Back"
        value={234}
        icon={UserX}
        description="Not following you back"
        colorClass="text-red-600"
      />
    </div>
  );
}