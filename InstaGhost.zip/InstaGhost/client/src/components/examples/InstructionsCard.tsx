import InstructionsCard from '../InstructionsCard';

export default function InstructionsCardExample() {
  return (
    <div className="p-6">
      <InstructionsCard />
    </div>
  );
}