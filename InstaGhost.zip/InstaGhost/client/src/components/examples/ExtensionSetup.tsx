import ExtensionSetup from '../ExtensionSetup';

export default function ExtensionSetupExample() {
  const handleDataReceived = (data: any) => {
    console.log('Data received:', data);
  };

  const handleGoBack = () => {
    console.log('Go back clicked');
  };

  return (
    <div className="p-6">
      <ExtensionSetup 
        onDataReceived={handleDataReceived}
        onGoBack={handleGoBack}
      />
    </div>
  );
}