import ProgressIndicator from '../ProgressIndicator';

export default function ProgressIndicatorExample() {
  // todo: remove mock functionality
  const mockSteps = [
    { label: 'Reading followers file', status: 'completed' as const },
    { label: 'Reading following file', status: 'completed' as const },
    { label: 'Analyzing data differences', status: 'processing' as const },
    { label: 'Generating results', status: 'pending' as const }
  ];

  return (
    <div className="p-6">
      <ProgressIndicator 
        steps={mockSteps}
        currentStep={2}
        progress={65}
      />
    </div>
  );
}